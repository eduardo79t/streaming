package com.codes.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

/**
 * Servlet implementation class HelloWorld
 */
@WebServlet("/HelloWorld")
public class HelloWorld extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HelloWorld() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 try{
			  response.setContentType("text/html");
		      PrintWriter printWriter  = response.getWriter();
		      printWriter.println("<h1>Hello with streaming World!</h1>");
			  AudioInputStream audioIn = AudioSystem.getAudioInputStream(new URL("http://www.europe1.fr/direct-video"));
			  Clip clip = AudioSystem.getClip();
			  clip.open(audioIn);
			  clip.start();
		  } catch (Exception e){
			  
			  System.out.println("ERROR: " + e.getMessage());
			  
		  }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 try{
			  AudioInputStream audioIn = AudioSystem.getAudioInputStream(new URL("http://www.europe1.fr/direct-video"));
			  Clip clip = AudioSystem.getClip();
			  clip.open(audioIn);
			  clip.start();
		  } catch (Exception e){
			  
			  System.out.println("ERROR: " + e.getMessage());
			  
		  }
	}

}
